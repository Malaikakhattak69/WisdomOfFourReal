from flask import Flask, request, jsonify
import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load your model (must be the same used for embedding generation)
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load the hadith texts
with open('imam_malik_texts_for_server.json.json', 'r', encoding='utf-8') as f:
    texts = json.load(f)

# Load the precomputed embeddings and FAISS index
embeddings = np.load('imam_malik_embeddings.npy')
index = faiss.read_index('imam_malik_faiss.index')

# Create Flask app
app = Flask(_name_)

@app.route('/')
def home():
    return "Imam Malik Chatbot API is running."

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    query = data.get('query')

    if not query:
        return jsonify({'error': 'Query is missing'}), 400

    # Convert query to embedding
    query_embedding = model.encode([query])
    
    # Search for the most similar hadith using FAISS
    D, I = index.search(np.array(query_embedding).astype('float32'), k=1)

    best_index = I[0][0]
    best_text = texts[best_index]['text']

    return jsonify({'text': best_text})

if _name_ == '_main_':
    app.run(debug=True)