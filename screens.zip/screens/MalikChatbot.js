import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
} from 'react-native';
import Colors from '../constants/colors';

export default function MalikChatbot() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  // Send the question to the backend API (simulated)
  const fetchAnswer = async (question) => {
    // You can replace this with an actual API call to your backend or a service like OpenAI.
    // Here we simulate a response.
    setLoading(true);
    setMessages((prev) => [...prev, { id: Date.now().toString(), text: `You asked: "${question}"`, sender: 'user' }]);
    
    // Simulate delay for API response
    setTimeout(() => {
      const response = `Imam Malik's answer to "${question}" is: [The response from backend].`; 
      setMessages((prev) => [...prev, { id: Date.now().toString(), text: response, sender: 'bot' }]);
      setLoading(false);
    }, 1000);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    fetchAnswer(input);
    setInput(''); // Clear input field after sending
  };

  const renderItem = ({ item }) => (
    <View
      style={[
        styles.messageBubble,
        item.sender === 'user' ? styles.userBubble : styles.botBubble,
      ]}
    >
      <Text style={styles.messageText}>{item.text}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={styles.inner}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={90}
      >
        <Text style={styles.header}>Ask Imam Malik (Bot)</Text>

        {/* Display chat messages */}
        <FlatList
          data={messages}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.chatContainer}
        />

        {/* Loading indicator */}
        {loading && <Text style={styles.loading}>...</Text>}

        {/* Input field and send button */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="Type your question..."
            placeholderTextColor="#aaa"
          />
          <TouchableOpacity onPress={handleSend} style={styles.sendButton}>
            <Text style={styles.sendText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  inner: {
    flex: 1,
    paddingHorizontal: 15,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.primary,
    textAlign: 'center',
    marginVertical: 12,
  },
  chatContainer: {
    paddingVertical: 10,
    paddingBottom: 20,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginVertical: 6,
  },
  userBubble: {
    backgroundColor: Colors.primary,
    alignSelf: 'flex-end',
  },
  botBubble: {
    backgroundColor: '#e0e0e0',
    alignSelf: 'flex-start',
  },
  messageText: {
    color: '#000',
    fontSize: 15,
  },
  loading: {
    textAlign: 'center',
    color: Colors.secondary,
    fontSize: 16,
    marginTop: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#ddd',
  },
  input: {
    flex: 1,
    height: 40,
    backgroundColor: '#f1f1f1',
    borderRadius: 20,
    paddingHorizontal: 15,
    color: '#000',
  },
  sendButton: {
    marginLeft: 10,
    backgroundColor: Colors.primary,
    borderRadius: 20,
    paddingHorizontal: 18,
    justifyContent: 'center',
  },
  sendText: {
    color: Colors.white,
    fontWeight: 'bold',
  },
});
